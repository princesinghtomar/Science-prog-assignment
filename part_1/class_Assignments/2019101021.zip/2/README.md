# Question 2
## Calculation of Value of 𝝿 using Monte Carlo
### Language
> python 3.9
### Requirents
> $ pip install -r requirements.txt
### Liberaries Used
> matplotlib

> random

> math
### Run
> $ python3 PIvN.py